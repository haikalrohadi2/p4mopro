#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\HP\Documents\KULIAH MUHAMMAD HAIKAL ROHADI\Semester 3\Kebutuhan Prak PBO\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\HP\Documents\KULIAH MUHAMMAD HAIKAL ROHADI\Semester 5\Mobile Programming\mobile_programming_local_storage"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
