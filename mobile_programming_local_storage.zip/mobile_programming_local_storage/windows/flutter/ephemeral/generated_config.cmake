# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 3\\Kebutuhan Prak PBO\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 3\\Kebutuhan Prak PBO\\flutter"
  "PROJECT_DIR=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage"
  "FLUTTER_ROOT=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 3\\Kebutuhan Prak PBO\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage"
  "FLUTTER_TARGET=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuMzUuMw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YTQwMmQ5YTQzNw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049MTUyN2FlMGVjNQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMC40"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\HP\\Documents\\KULIAH MUHAMMAD HAIKAL ROHADI\\Semester 5\\Mobile Programming\\mobile_programming_local_storage\\.dart_tool\\package_config.json"
)
